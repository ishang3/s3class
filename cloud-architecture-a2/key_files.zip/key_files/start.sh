# stop script on error
set -e

# Check to see if root CA file exists, download if not
if [ ! -f ./root-CA.crt ]; then
  printf "\nDownloading AWS IoT Root CA certificate from AWS...\n"
  curl https://www.amazontrust.com/repository/AmazonRootCA1.pem > root-CA.crt
fi

# Check to see if AWS Device SDK for Python exists, download if not
if [ ! -d ./aws-iot-device-sdk-python ]; then
  printf "\nCloning the AWS SDK...\n"
  git clone https://github.com/aws/aws-iot-device-sdk-python.git
fi

# Check to see if AWS Device SDK for Python is already installed, install if not
if ! python -c "import AWSIoTPythonSDK" &> /dev/null; then
  printf "\nInstalling AWS SDK...\n"
  pushd aws-iot-device-sdk-python
  python setup.py install
  result=$?
  popd
  if [ $result -ne 0 ]; then
    printf "\nERROR: Failed to install SDK.\n"
    exit $result
  fi
fi

# run pub/sub sample app using certificates downloaded in package
printf "\nRunning pub/sub sample application...\n"
#python aws-iot-device-sdk-python/samples/basicPubSub/basicPubSub.py -e a3uxhx2wvbys89-ats.iot.us-east-2.amazonaws.com -r root-CA.crt -c MacAirPers.cert.pem -k MacAirPers.private.key



python aws-iot-device-sdk-python/samples/basicPubSub/basicPubSub.py -e a3uxhx2wvbys89-ats.iot.us-east-2.amazonaws.com -r root-CA.crt -c 2844a6fa72-cert.pem -k 2844a6fa72-private.pem.key


python /Users/ishan/Documents/cloud/iotcore/aws-iot-device-sdk-python-v2/samples/pubsub.py --e a3uxhx2wvbys89-ats.iot.us-east-2.amazonaws.com --r root-CA.crt --c 2844a6fa72-cert.pem --k 2844a6fa72-private.pem.key


