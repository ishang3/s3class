# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0.

from __future__ import absolute_import
from __future__ import print_function
import argparse
from awscrt import io, mqtt, auth, http
from awsiot import mqtt_connection_builder
import sys
import threading
import time
from uuid import uuid4
import boto3
import json
from decimal import *
import queue
import threading

# This sample uses the Message Broker for AWS IoT to send and receive messages
# through an MQTT connection. On startup, the device connects to the server,
# subscribes to a topic, and begins publishing messages to that topic.
# The device should receive those same messages back from the message broker,
# since it is subscribed to that same topic.

parser = argparse.ArgumentParser(description="Send and receive messages through and MQTT connection.")
parser.add_argument('--e', required=True, help="Your AWS IoT custom endpoint, not including a port. " +
                                                      "Ex: \"abcd123456wxyz-ats.iot.us-east-1.amazonaws.com\"")
parser.add_argument('--c', help="File path to your client certificate, in PEM format.")
parser.add_argument('--k', help="File path to your private key, in PEM format.")
parser.add_argument('--r', help="File path to root certificate authority, in PEM format. " +
                                      "Necessary if MQTT server uses a certificate that's not already in " +
                                      "your trust store.")
parser.add_argument('--client-id', default="muvvaMac", help="Client ID for MQTT connection.")
parser.add_argument('--topic', default="sdktestcpp", help="Topic to subscribe to, and publish messages to.")
parser.add_argument('--message', default="Hello World!", help="Message to publish. " +
                                                              "Specify empty string to publish nothing.")
parser.add_argument('--count', default=0, type=int, help="Number of messages to publish/receive before exiting. " +
                                                          "Specify 0 to run forever.")
parser.add_argument('--use-websocket', default=False, action='store_true',
    help="To use a websocket instead of raw mqtt. If you " +
    "specify this option you must specify a region for signing, you can also enable proxy mode.")
parser.add_argument('--signing-region', default='us-east-2', help="If you specify --use-web-socket, this " +
    "is the region that will be used for computing the Sigv4 signature")
parser.add_argument('--proxy-host', help="Hostname for proxy to connect to. Note: if you use this feature, " +
    "you will likely need to set --root-ca to the ca for your proxy.")
parser.add_argument('--proxy-port', type=int, default=8080, help="Port for proxy to connect to.")
parser.add_argument('--verbosity', choices=[x.name for x in io.LogLevel], default=io.LogLevel.NoLogs.name,
    help='Logging level')

# Using globals to simplify sample code
args = parser.parse_args()

io.init_logging(getattr(io.LogLevel, args.verbosity), 'stderr')

received_count = 0
received_all_event = threading.Event()
dynamodb = boto3.resource('dynamodb', region_name='us-west-2')
table = dynamodb.Table('ishan-test')
BUF_SIZE = 4000
q = queue.Queue(BUF_SIZE)
lock1 = threading.Lock()


# Callback when connection is accidentally lost.
def on_connection_interrupted(connection, error, **kwargs):
    print("Connection interrupted. error: {}".format(error))


# Callback when an interrupted connection is re-established.
def on_connection_resumed(connection, return_code, session_present, **kwargs):
    print("Connection resumed. return_code: {} session_present: {}".format(return_code, session_present))

    if return_code == mqtt.ConnectReturnCode.ACCEPTED and not session_present:
        print("Session did not persist. Resubscribing to existing topics...")
        resubscribe_future, _ = connection.resubscribe_existing_topics()

        # Cannot synchronously wait for resubscribe result because we're on the connection's event-loop thread,
        # evaluate result with a callback instead.
        resubscribe_future.add_done_callback(on_resubscribe_complete)


def on_resubscribe_complete(resubscribe_future):
        resubscribe_results = resubscribe_future.result()
        print("Resubscribe results: {}".format(resubscribe_results))

        for topic, qos in resubscribe_results['topics']:
            if qos is None:
                sys.exit("Server rejected resubscribe to topic: {}".format(topic))





def on_message_received1(topic, payload, **kwargs):
    global count
    count += 1
    print(count)





if __name__ == '__main__':
    # Spin up resources
    event_loop_group = io.EventLoopGroup(1)
    host_resolver = io.DefaultHostResolver(event_loop_group)
    client_bootstrap = io.ClientBootstrap(event_loop_group, host_resolver)
    global counter
    counter = 0

    mqtt_connection = mqtt_connection_builder.mtls_from_path(
            endpoint=args.e,
            cert_filepath=args.c,
            pri_key_filepath=args.k,
            client_bootstrap=client_bootstrap,
            ca_filepath=args.r,
            on_connection_interrupted=on_connection_interrupted,
            on_connection_resumed=on_connection_resumed,
            client_id=args.client_id,
            clean_session=False,
            keep_alive_secs=6)

    print("Connecting to {} with client ID '{}'...".format(
        args.e, args.client_id))

    connect_future = mqtt_connection.connect()

    # Future.result() waits until a result is available
    connect_future.result()
    print("Connected!")

    # c = ConsumerThread(name='consumer')
    # c.start()

    # creating a lock
    lock = threading.Lock()
    global count
    count = 0

    tp_future, packet_id = mqtt_connection.subscribe(
        topic='sdktestcpp',
        qos=mqtt.QoS.AT_MOST_ONCE,
        callback=on_message_received1)

    received_all_event.wait()

    # for i in range(2):
    #     print("Subscribing to topic '{}'...".format(args.topic+str(i)))
    #     tp ="on_message_received"+str(i)
    #     tp_future = "subscribe_future"+str(i)
    #     print("call back name:",tp)
    #     tp_future, packet_id = mqtt_connection.subscribe(
    #         topic=args.topic+str(i),
    #         qos=mqtt.QoS.AT_MOST_ONCE,
    #         callback=tp)
    #
    #     # subscribe_future, packet_id = mqtt_connection.subscribe(
    #     #     topic=args.topic+str(1),
    #     #     qos=mqtt.QoS.AT_MOST_ONCE,
    #     #     callback=on_message_received1)
    #     # tp_result ="subscribe_result"+str(i)
    #     # tp_result = tp_future.result()
    #     # print("Subscribed with {}".format(str(tp_result['qos'])))
    # received_all_event.wait()

    # c = ConsumerThread(name='consumer')
    # c.start()

